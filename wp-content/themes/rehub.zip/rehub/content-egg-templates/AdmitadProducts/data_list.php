<?php
/*
  Name: Sorted list
 */  
?>
<?php include(rh_locate_template('inc/ce_common/data_list.php')); ?>