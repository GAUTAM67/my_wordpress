<?php
/*
  Name: Big product cart without title
 */

?>
<?php include(rh_locate_template('inc/ce_common/data_bigcart_notitle.php')); ?>