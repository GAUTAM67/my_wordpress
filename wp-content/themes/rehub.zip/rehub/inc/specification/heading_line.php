<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<h4>
<?php $heading = (!empty($row['heading_line'])) ? $row['heading_line'] : '' ;?>
<?php echo $heading;?>                                  
</h4>